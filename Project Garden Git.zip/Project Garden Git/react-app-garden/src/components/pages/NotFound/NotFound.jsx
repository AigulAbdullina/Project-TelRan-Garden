import s from './NotFound.module.scss';

const NotFound = () => {
  return (
    <div className={s.notFound}>
    </div>
  );
};

export default NotFound;
